
interface OpenList{
    public boolean isEmpty();
    public void push(int u);
    public int pop();
    int [] arraylist=new int[100];
}